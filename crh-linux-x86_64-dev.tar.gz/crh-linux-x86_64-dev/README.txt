CRH Linux x86_64 DEVELOPMENT client

Built from the pinned unmodified Horizon source plus Create Reborn native mixins.
This is a development build with no default features, no debug info and no
incremental output. It is not a gameplay-certified release. Audio/friends/
controller feature support is not implied. No Minecraft/Create JARs, prepared
Minecraft resources or original Create artwork are included.

Keep horizon-client, native-mods.json and native-data together. Run from a NEW
empty instance directory with your prepared Minecraft 26.3 resources:

  printf 'mod.create:true\n' > horizon-mods.txt
  /path/to/this/horizon-client --resources /your/prepared/resources --world CRHReview --creative

The game needs facts.json and horizon-resources.json plus the other prepared data.
Horizon Launcher prepares these through your own Minecraft account/installation.
The optional original Create artwork importer remains local and optional.

Prefer installing the validated .hnmod into a NEW Minecraft 26.3 Horizon Launcher
instance for normal desktop use, especially on Windows. This Linux executable
cannot run natively on Windows. Neither the native cache integration nor the
acceptance scenarios have passed real-game validation in this environment.

See the GitHub repository packaging/README.md and docs/core-acceptance.md for
installation, source build pins and the automated isolated-world acceptance run.
All required runtime resources remain private to your installation.
